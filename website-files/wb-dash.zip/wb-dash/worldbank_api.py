"""

File: worldbank_api.py
Authors: Paul Champagne & Oscar Nesbitt-Schnadt

Description: 
    The primary API for interacting with the World Bank Dataset.
    The file takes in relevant economic indicators accesible through
    the API and returns historic data of such indicators based on
    specified countries.

Division of Tasks:
    Both collaborated together on the file. We both worked together
    on obtaining/determining relevant indicators. Oscar built the fetch_countries 
    function while Paul worked on the fetch_wbdata function. Split up writing comments.

"""

# Import libraries
import requests
import pandas as pd

class WBAPI:
    def __init__(self):

        # Define World Bank database indicators
        self.indicators = {
            "GDP": "NY.GDP.MKTP.CD",
            "GDP Growth Rate": "NY.GDP.MKTP.KD.ZG",
            "GDP per Capita": "NY.GDP.PCAP.CD",
            "Inflation Rate": "FP.CPI.TOTL.ZG",
            "Unemployment Rate": "SL.UEM.TOTL.ZS",
            "Interest Rate": "FR.INR.RINR",
        }
    
    def fetch_countries(self):
        """
        Fetches all available countries from the World Bank API.
        Returns all countries in a list (country_lst)
        """
        
        # Request url to get country list (in JSON format)
        url = "https://api.worldbank.org/v2/country?format=json&per_page=300"
        response = requests.get(url)

        # Get a list of all countries (removing all regions/continents) from request, return empty list if request fails
        if response.status_code == 200:
            data = response.json()[1]
            country_lst = [f"{country['name']} ({country['id']})" for country in data if country['region']['id'] != 'NA']
            return country_lst
        else:
            return []
    
    def fetch_wbdata(self, country_code, indicator, start_year, end_year):
        """
        Fetch data from the World Bank API for a specific country, indicator, start year, and end year.
        Returns dataframe with corresponding values for indicator and country for the date range.
        """

        # Get indicator code based on indicator dictionary in constructor method
        indicator_code = self.indicators.get(indicator)

        # Request url to get indicator data based on country and date range (in JSON format)
        url = f"https://api.worldbank.org/v2/country/{country_code}/indicator/{indicator_code}?date={start_year}:{end_year}&format=json&per_page=1000"
        response = requests.get(url)

        # Return df of indicator data if request is successful
        if response.status_code == 200:
            
            data = response.json()[1]
            
            # Turn data into df
            df = pd.DataFrame({
                'Year': [entry['date'] for entry in data],
                indicator: [entry['value'] for entry in data]
                })
            
            # Change year to int data type and sort df based on year
            df['Year'] = pd.to_numeric(df['Year'])
            df = df.sort_values(by='Year').reset_index(drop=True)

        return df