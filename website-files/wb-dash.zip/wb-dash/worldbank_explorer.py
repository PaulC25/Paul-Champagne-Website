"""
File: worldbank_explorer.py
Authors: Paul Champagne & Oscar Nesbitt-Schnadt

Description:
    Creates Holoviz Panel using World Bank Data API. The panel
    has two main tabs. One is an interactive line plot which
    shows the trend in indicator data between any number of 
    inputted countries (for the selected number of years).
    The other is a table tab which shows country data (either
    raw data or summary statistics) for any number of selected
    indicators, for a range of years.

Division of Work:
    Both worked together in writing file. Paul focused on the
    get_table and show_table functions (as well as their relevant
    widgets) while Oscar focused on the create_plot function (and
    its relevant widgets). Both worked together in adjusting the 
    layout of the panel and writing the comments.

"""

# Import libraries
import panel as pn
import pandas as pd
import plotly.graph_objects as go
from worldbank_api import WBAPI

# Configure panel
pn.extension()

# Initialize the API class
api = WBAPI()

# Get list of available countries
country_lst = api.fetch_countries()

# WIDGET DECLARATIONS

# Widgets dealing with indicator choice(s)

indicator_dropdown = pn.widgets.Select(name="Select Indicator", options=list(api.indicators.keys()))

indicator_selector = pn.widgets.MultiChoice(
    name="Select Indicators",
    options=list(api.indicators.keys()),
    placeholder="Choose Indicators...",
    value=["GDP"]
)

# Widgets dealing with country choice(s)
search_bar = pn.widgets.AutocompleteInput(
    name="Country Options",
    options=country_lst,
    placeholder="Type to select country",
    case_sensitive=False,
    min_characters=1,
    value="United States (USA)"
)

country_selector = pn.widgets.MultiChoice(
    name="Select Countries",
    options=country_lst,
    placeholder="Choose countries...",
    value=["United States (USA)"]
)

# Widget to determine year range
year_slider = pn.widgets.IntRangeSlider(name="Year Range", start=1960, end=2023, value=(2010, 2023))

# Widget to choose which type of table is displayed 
show_type = pn.widgets.Select(name='Display', options=['Raw Data', 'Summary Statistics'])

# Widgets to adjust height and width of plot/table
width_slider = pn.widgets.IntSlider(name='Width', start=250, end=1500, step=100, value=800)
height_slider = pn.widgets.IntSlider(name='Height', start=200, end=1200, step=50, value=600)


# Panel plot container for Plotly
plot_pane = pn.pane.Plotly(sizing_mode="stretch_width")


def create_plot(indicator, selected_countries, year_range, height, width):
    """
    Parameters:
        1) indicator: indicator code selected (from indicator_dropdown widget)
        2) selected_countries: list of countries (from country_selector widget)
        3) year_range: tuple representing range of years (from year_slider widget)
        4) height: int representing height of plot (from height_slider widget)
        5) width: int representing width of plot (from width_slider widget)
    
    Description:
        Function creates plotly line plot based an indicator, any selected 
        countries, and a year range.
        Function also takes in a height and width parameter to change the 
        plot's size.
    
    Returns:
        1) fig: Plotly figure of line plot based on corresponding contries and
        indicator, over inputted time range.
    """

    # Extract the country codes from the selected country names
    country_codes = [abbr.split('(')[-1][:-1] for abbr in selected_countries]
    start_year, end_year = year_range

    # Dictionary to store data for each country
    df_dict = {}

    # Fetch data for each country and indicator
    for country in country_codes:
        df_dict[country] = api.fetch_wbdata(country, indicator, start_year, end_year)

    # Create a Plotly figure
    fig = go.Figure()

    # Add data traces for each country
    for country, df in df_dict.items():
        fig.add_trace(go.Scatter(x=df.iloc[:, 0], y=df.iloc[:, 1], mode='lines+markers', name=country))

    # Customize the layout
    country_name = ", ".join(country_selector.value)
    fig.update_layout(
        title=f"{indicator_dropdown.value} for {country_name} from {start_year} to {end_year}",
        xaxis_title="Year",
        yaxis_title=f"{indicator_dropdown.value}",
        height = height,
        width = width,
        hovermode='x unified'
    )

    # Update the plot_pane with the new figure
    plot_pane.object = fig
    
    return fig

def get_table(selected_indicators, country, year_range):
    """
    Parameters:
        1) selected_indicators: list of indicators (from indicator_selector widget)
        2) country: country code selected (from search_bar widget)
        3) year_range: tuple representing range of years (from year_slider widget)

    Description:
        For a specified country, function generates a df (raw data) and summary statistics of 
        that df based on selected indicators and year range
    
    Returns:
        1) df_describe: Summary Statistics Dataframe
        2) combined_df: Raw Data Dataframe

    """
    
    # Extract country code
    country_code = country.split('(')[-1].strip(')')

    # Collect each indicator in selected_indicator parameter
    indicator_lst = [indicator for indicator in selected_indicators]
    
    # Create a combined df that merges each indicator based on the year
    indicator_n1 = indicator_lst[0]
    combined_df = api.fetch_wbdata(country_code, indicator_n1, year_range[0], year_range[1])
    for indicator in indicator_lst[1:]:
        df = api.fetch_wbdata(country_code, indicator, year_range[0], year_range[1])
        combined_df = pd.merge(combined_df, df, on='Year', how='outer')
    
    # Round any columns with floats to 3 decimal places
    float_cols = combined_df.select_dtypes(include=['float'])
    combined_df[float_cols.columns] = float_cols.round(3)

    # Generate the statistical summary using df.describe()
    df_describe = combined_df.drop(columns=['Year']).describe().round(3)
    
    return df_describe, combined_df


def show_table(selected_indicators, country, year_range, show_type, height, width):
    """
    Parameters:
        1) selected_indicators: list of indicators (from indicator_selector widget)
        2) country: country code selected (from search_bar widget)
        3) year_range: tuple representing range of years (from year_slider widget)
        4) show_type: value that determines type of display for table
        5) height: int representing height of table (from height_slider widget)
        6) width: int representing width of table (from width_slider widget)

    Description:
        Creates data pane and title fir table based on selected display widget
        (show_type) from the get_table function.
    
    Returns:
        pn.Column showing the table and its respective title
    """
    # Get the combined DataFrame and the describe df
    df_describe, combined_df = get_table(selected_indicators, country, year_range)
    
    # Return based on the selected option ('Raw Data' or 'Summary Statistics')
    if show_type == 'Raw Data':
        title = pn.pane.Markdown(f"## Data Table for {country} ({year_range[0]} - {year_range[1]})")
        table = pn.pane.DataFrame(combined_df, width=width, height=height, index=False)
    elif show_type == 'Summary Statistics':
        title = pn.pane.Markdown(f"## Summary Statistics for {country} ({year_range[0]} - {year_range[1]})")
        table = pn.pane.DataFrame(df_describe, width=width, height=height, index=True)
    
    return pn.Column(title, table)


# CALLBACK BINDINGS

# Binding for create_plot function
plot = pn.bind(create_plot, 
                 indicator_dropdown.param.value, 
                 country_selector.param.value, 
                 year_slider.param.value, 
                 height_slider.param.value, 
                 width_slider.param.value)

# Binding for show_table function
table = pn.bind(show_table, 
                indicator_selector.param.value, 
                search_bar.param.value, 
                year_slider.param.value, 
                show_type.param.value,
                height_slider.param.value,
                width_slider.param.value)





# Sidebar tabs
sidebar_tabs = pn.Tabs(
    ("Plot Settings", pn.Column(
        indicator_dropdown,
        country_selector,
        year_slider,
        height_slider,
        width_slider
    )),
    ("Table Settings", pn.Column(
        search_bar,
        indicator_selector,
        year_slider,
        show_type,
        height_slider,
        width_slider
    )),
)

# Main tabs tied to callback bindings
tabs = pn.Tabs(("Line Plot", plot),("Table", table), active = 0)

def sync_tabs(event):
    """ 
    Function syncs tabs so that the sidebar tabs changes
    when the main tabs change (and vice versa)
    """
    sidebar_tabs.active = event.new
    tabs.active = event.new

# Watch the active state of both tab sets and sync them
sidebar_tabs.param.watch(lambda event: sync_tabs(event), 'active')
tabs.param.watch(lambda event: sync_tabs(event), 'active')

#LAYOUT

layout = pn.template.GoldenTemplate(
    title='World Bank Economic Data Explorer',
    logo='https://images.seeklogo.com/logo-png/52/1/world-bank-logo-png_seeklogo-521136.png',
    sidebar=sidebar_tabs,
    sidebar_width=30,
    main=tabs
).servable()


layout.show()
